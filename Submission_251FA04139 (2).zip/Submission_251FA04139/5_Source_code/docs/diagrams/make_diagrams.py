"""Draws the project diagrams as PNG (matplotlib). The .mmd files are the same diagrams in Mermaid."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

NAVY, TEAL, RED, GREY, LIGHT = "#12263A", "#0F7B8A", "#C8372D", "#5A6B7B", "#EAF2F5"

def box(ax, x, y, w, h, text, fc=LIGHT, ec=TEAL, fs=10, tc=NAVY, bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08", fc=fc, ec=ec, lw=1.6))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, color=tc,
            fontweight="bold" if bold else "normal", wrap=True)

def arrow(ax, p, q, color=GREY, style="-|>"):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle=style, mutation_scale=14, lw=1.6, color=color,
                                 shrinkA=0, shrinkB=0))

def canvas(w, h):
    fig, ax = plt.subplots(figsize=(w, h)); ax.set_xlim(0, w); ax.set_ylim(0, h); ax.axis("off")
    return fig, ax

# ---------- architecture ----------
fig, ax = canvas(14, 6.4)
ax.text(0.2, 6.05, "System architecture", fontsize=15, fontweight="bold", color=NAVY)
ax.text(0.2, 5.7, "Offline data preparation  ->  ML detector  ->  attack-path search  ->  dashboard", fontsize=10, color=GREY)
# row 1 data
r1 = [("CIC-IDS2017 CSVs\nTuesday (FTP/SSH-Patator)\nWednesday (DoS), Friday (DDoS)", 0.3), ("CICFlowMeter flow\nfeatures + Label\n(as downloaded)", 3.9), ("core.py: sample rows\nin chunks, clean,\nlabel 0/1", 7.3), ("70/30 stratified\nsplit (seed 42)", 10.4)]
for t, x in r1: box(ax, x, 4.2, 2.9 if x < 10 else 3.0, 1.2, t, fs=9.5)
for a, b in ((3.2, 3.9), (6.8, 7.3), (10.2, 10.4)): arrow(ax, (a, 4.8), (b, 4.8))
arrow(ax, (11.9, 4.2), (11.9, 3.45))
# row 2 ML
box(ax, 10.4, 2.3, 3.0, 1.15, "Random Forest\n100 trees, balanced classes", fc="#DDF1F3", fs=10, bold=True)
arrow(ax, (10.4, 2.9), (9.3, 2.9))
box(ax, 6.1, 2.3, 3.2, 1.15, "Metrics on unseen 30%\naccuracy, precision, recall,\nF1, confusion matrix", fs=9.5)
arrow(ax, (11.9, 2.3), (11.9, 1.55))
box(ax, 10.4, 0.45, 3.0, 1.1, "Threat level =\nmean P(malicious)\nover 200 flows", fc="#FBE6E3", ec=RED, fs=9.5)
arrow(ax, (10.4, 1.0), (9.3, 1.0), color=RED)
box(ax, 6.1, 0.45, 3.2, 1.1, "Node risk and cost\n(simulated 10-node network)", fs=9.5)
arrow(ax, (6.1, 1.0), (5.0, 1.0))
box(ax, 1.9, 0.45, 3.1, 1.1, "BFS / DFS / A*\npath, cost, nodes expanded", fc="#DDF1F3", fs=9.5, bold=True)
arrow(ax, (1.9, 1.0), (1.0, 1.0)); 
box(ax, 0.2, 0.2, 1.6, 1.6, "Streamlit\ndashboard\n(app.py)", fc=NAVY, ec=NAVY, tc="white", fs=10, bold=True)
arrow(ax, (6.1, 2.9), (1.0, 2.9), color=GREY); arrow(ax, (1.0, 2.9), (1.0, 1.8))
ax.text(0.3, 3.2, "metrics", fontsize=8.5, color=GREY)
fig.savefig("architecture.png", dpi=170, bbox_inches="tight", facecolor="white"); plt.close(fig)

# ---------- workflow ----------
fig, ax = canvas(14, 6)
ax.text(0.2, 5.65, "Step-by-step workflow", fontsize=15, fontweight="bold", color=NAVY)
ax.text(0.2, 5.3, "PART 1 - Machine learning (what the app does when you upload a file)", fontsize=10.5, color=TEAL, fontweight="bold")
s1 = ["1 Upload CSV\nor give path", "2 Sample rows\nfrom every chunk", "3 Clean: inf/NaN,\nheader rows, IDs", "4 Split\n70% train / 30% test", "5 Train\nRandom Forest", "6 Predict the\nunseen 30%", "7 Show metrics +\nconfusion matrix"]
w = 1.78
for i, t in enumerate(s1):
    x = 0.2 + i * 1.95
    box(ax, x, 3.7, w, 1.1, t, fs=9)
    if i: arrow(ax, (x - 0.17, 4.25), (x, 4.25))
ax.text(0.2, 2.95, "PART 2 - Attack-path search (driven by the ML output)", fontsize=10.5, color=RED, fontweight="bold")
s2 = ["8 Pick traffic window\nmixed / benign / attack", "9 Threat level =\nmean P(malicious)", "10 Update risk\nand cost of nodes", "11 Run BFS, DFS, A*", "12 Compare cost,\nnodes, runtime", "13 Draw the\nattack path"]
w2 = 2.15
for i, t in enumerate(s2):
    x = 0.2 + i * 2.3
    box(ax, x, 1.4, w2, 1.1, t, fc="#FBE6E3", ec=RED, fs=9)
    if i: arrow(ax, (x - 0.15, 1.95), (x, 1.95), color=RED)
ax.text(0.2, 0.7, "Error path: if the sample contains only one class, the app stops with a clear message instead of training.", fontsize=9.5, color=GREY)
ax.text(0.2, 0.3, "All steps 1-13 are implemented in core.py / app.py. Real-CSV results must still be produced on your computer.", fontsize=9.5, color=GREY)
fig.savefig("workflow.png", dpi=170, bbox_inches="tight", facecolor="white"); plt.close(fig)

# ---------- ML -> search link ----------
fig, ax = canvas(14, 3.6)
ax.text(0.2, 3.25, "How the ML model changes the search", fontsize=15, fontweight="bold", color=NAVY)
items = [("Network flows\n(test set)", 0.2, LIGHT, TEAL), ("Random Forest\nP(malicious) per flow", 2.55, "#DDF1F3", TEAL), ("Average over\n200 flows =\nthreat (0..1)", 4.9, "#FBE6E3", RED),
         ("Exposed nodes:\nrisk = base x (0.5+threat)\nInternal: risk = base", 7.25, LIGHT, TEAL), ("cost = max(0.05, 1 - risk)", 9.9, LIGHT, TEAL), ("A*: f = g + h\nh = hops left x 0.05", 12.0, "#DDF1F3", TEAL)]
ws = [2.0, 2.0, 2.0, 2.3, 1.9, 1.8]
for (t, x, fc, ec), w in zip(items, ws):
    box(ax, x, 1.0, w, 1.4, t, fc=fc, ec=ec, fs=9)
for a, b in ((2.2, 2.55), (4.55, 4.9), (6.9, 7.25), (9.55, 9.9), (11.8, 12.0)): arrow(ax, (a, 1.7), (b, 1.7))
ax.text(7.25, 0.55, "BASE_VULN = hand-set assumption (not measured)", fontsize=9, color=RED)
fig.savefig("ml_search_link.png", dpi=170, bbox_inches="tight", facecolor="white"); plt.close(fig)
